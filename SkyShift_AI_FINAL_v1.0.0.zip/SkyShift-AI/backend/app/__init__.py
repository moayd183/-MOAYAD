"""SkyShift AI application package."""
