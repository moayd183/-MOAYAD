"""Astronomy service adapters."""
